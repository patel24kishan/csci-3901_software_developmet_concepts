Final Project.zip contains all the files

config Folder - contains all config files for Government class object and for initializing different MobileDevices

src Folder - Contains main solution files (Government.java, MobileDevice.java, MobileDeviceData.java, Pair.java)
            and JUnit testing file (Testing.java)

Documentation.pdf - final Documentation of code

SQLscript.sql - script to generate tables in the database mentioned in the Documentation.pdf