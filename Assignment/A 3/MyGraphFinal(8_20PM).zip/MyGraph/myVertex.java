
public class myVertex {

	private String valueCharacter;
	private int Weight;
	
	public myVertex(String value,int Wt)
	{
		this.valueCharacter=value;
		this.Weight=Wt;	
	}
	
	public String getVertex() {
		return valueCharacter;
	}

	public int getWeight() {
		return Weight;
	}
}
