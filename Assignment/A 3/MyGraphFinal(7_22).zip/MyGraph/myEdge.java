
public class myEdge {

	public String sourceVertice;
	public String destinationVertice;
	public int weight;
	
	public myEdge(String A, String B, int wt)
	{ 
		this.sourceVertice=A;
		this.destinationVertice=B;
		this.weight=wt;
	}
	
	public String getSource()
	{
		return sourceVertice;
	}
	
	public String getDestination() {
		return destinationVertice;
	}
	
	public int getWeight() {
		return weight;
	}

}
