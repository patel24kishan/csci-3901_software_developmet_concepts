

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;



import java.util.Set;

public class MyTestGraph {

	public HashMap<String, LinkedList<myVertex>> vertexListHashMap=
										new HashMap<String, LinkedList<myVertex>>(); //Keeps Track of each vertex connections
	
	public HashMap<String,myEdge> edgeList=new HashMap<String,myEdge>(); // List of all Edges
	
	public HashMap<String,Integer> verticesList=new HashMap<String,Integer>();; // List of individual Vertices along with corresponding weights
	
	// Initializing Constructor
	public  MyTestGraph()
	{
		
	}
	
	/********************************************* addEdge Method *********************************************/
	
	public boolean addEdge(String source,String destination,int weight)
	{
		String tempSource=source.replaceAll("\s+","");
		String tempDestination=destination.replaceAll("\s+","");

		if (tempSource.isBlank() ||tempSource.isEmpty() || tempSource.length()>1)
		{
			System.out.println("Invalid Source !!!");
			return false;
		}
		if (tempDestination.isBlank() ||tempDestination.isEmpty() || tempDestination.length()>1)
		{
			System.out.println("Invalid destination !!!");
			return false;
		}
		if (weight==0 || weight<0) 
		{
			System.out.println("Invalid Weight !!!");
			return false;
		}
		
		String finalSource; //Remove white spaces from source parameter
		String finalDestination;  //Remove white spaces from destination parameter
		
		if(tempSource.charAt(0)<tempDestination.charAt(0))
		{
			finalSource=tempSource;
			finalDestination=tempDestination;
		}
		else
		{
		finalSource=tempDestination;
		finalDestination=tempSource;
		}
		myEdge newEdge=new myEdge(finalSource,finalDestination, weight);	
		myVertex nextVertexA=new myVertex(finalDestination, weight);
		myVertex nextVertexB=new myVertex(finalSource, weight);
		
		
		if (!edgeList.containsKey(finalSource+finalDestination)  && !edgeList.containsKey(finalDestination+finalSource) ) 
		{
		//	System.out.println("Edge Added!!!");
			edgeList.put(finalSource+finalDestination,newEdge);
		
		
		///Implement for Source
			if (vertexListHashMap.containsKey(finalSource) )
			{
				LinkedList<myVertex> tmpLinkedList=vertexListHashMap.get(finalSource);
				tmpLinkedList.add(nextVertexA);
				vertexListHashMap.put(finalSource, tmpLinkedList);
				//System.out.println(" Vertex added to list of srce "+source+" & total Vertex = "+vertexListHashMap.get(source).size());
			
			}
			else
			{
				//System.out.println("New Vertex Added");
				LinkedList<myVertex> tmpLinkedList=new LinkedList<myVertex>();
				tmpLinkedList.push(nextVertexA);
				vertexListHashMap.put(finalSource, tmpLinkedList);
				
				verticesList.put(finalSource,1);
			}
		
			///Implment for destination
			if (vertexListHashMap.containsKey(finalDestination) )
			{
				LinkedList<myVertex> tmpLinkedList=vertexListHashMap.get(finalDestination);
				tmpLinkedList.add(nextVertexB);
				vertexListHashMap.put(finalDestination, tmpLinkedList);
			//	System.out.println(" Vertex added to list of dstn "+destination+" & total Vertex = "+vertexListHashMap.get(destination).size());
			
			}
			else
			{
				//System.out.println("New Vertex Added");
				LinkedList<myVertex> tmpLinkedList=new LinkedList<myVertex>();
				tmpLinkedList.push(nextVertexB);
				vertexListHashMap.put(finalDestination, tmpLinkedList);	
				
				verticesList.put(finalDestination,1);		
			}
		}
		else
		{
			System.err.println("Already edge exists");
			return false;
		}
		return true;
	}

	/********************************************* clusterVertices Method *********************************************/
	
	public Set<Set<String>> clusterVertices(float tolerance)
	{
		if (tolerance<0)
		 {
			return null;
		 }
		Set<Set<String>> clusterSets=new HashSet<Set<String>>();
		
		List<VertexClusterWeight> tempClusterSet=new ArrayList<VertexClusterWeight>();
		
		HashMap<String, myEdge> sortedEdgeList=sortHashMapbyWeight(edgeList);
		
		//Initialize tempclusterSet with max 20 empty Set object
		for (int i = 0; i < verticesList.size(); i++)
		{
			VertexClusterWeight VCW=new VertexClusterWeight();
			tempClusterSet.add(i,VCW);
		}
		
		
		
		boolean firstEdge=true;
		int i=0;
		for (Map.Entry<String, myEdge>  edgeObject : sortedEdgeList.entrySet())
		{
			
			
			int	 weight=edgeObject.getValue().getWeight();
			String vertex1=edgeObject.getValue().getSource();
			String vertex2=edgeObject.getValue().getDestination();
			
			int weightOfVertex1=verticesList.get(vertex1);
			int weightOfVertex2=verticesList.get(vertex2);
			
			System.out.println("Edge "+i++ +"--> V1= "+vertex1+"  V2= "+vertex2 +"  wt= "+weight);
			int minValue=minimumWeight(tempClusterSet, vertex1, vertex2);
			float ratio=(float)weight/minValue;
			System.out.println("Ratio= "+ratio);
			if (ratio<=tolerance)
			{

				// If First Edge is been Tranversed
				if (firstEdge) 
				{
					
					System.err.println("First Edge");
					tempClusterSet.get(0).addVertex(vertex1);
					tempClusterSet.get(0).addVertex(vertex2);
				
					if (weight>weightOfVertex1 || weight>weightOfVertex2)
					{
						verticesList.
						put(CompareVertex(vertex1, vertex2), weight);	
					}
					tempClusterSet.get(0).addweight(maximumWeight(tempClusterSet.get(0).getSet()));
				
			//	System.out.println(" Vertex in firstEdge "+tempClusterSet.get(0).getSet()+" "+tempClusterSet.get(0).getWeight());
					firstEdge=false;
					
				}
				else
				{
					System.out.println(" Vertex in IF(r satisfies)>ELSE "+vertex1+" "+vertex2);
				
						boolean v1Flag=false,v2Flag=false;
						int v1Index=-1,v2Index=-1;
					for (int j = 0; j < tempClusterSet.size(); j++)
					{	
						
				
							List<String>list1=tempClusterSet.get(j).getSet();
							//System.err.println(list1);
							if (list1.contains(vertex1))
							{
								
								v1Index=j;
								v1Flag=true;
							}
							if (list1.contains(vertex2))
							{
								
								v2Index=j;
								v2Flag=true;
							}
					}
					System.err.println("v1Flag= "+v1Flag+" v2flag= "+v2Flag);
						if (v1Flag==true && v2Flag==true)
						{
							//	System.out.println(v1Index+" "+v2Index);
							if (v1Index!=v2Index)
							{
								tempClusterSet.get(v1Index).getSet().addAll(tempClusterSet.get(v2Index).getSet());
								
								
								if (weight>weightOfVertex1 || weight>weightOfVertex2)
								{
									System.out.println(" Vertex in IF(true)>ELSE>IF(v1F-v2F)>IF "+vertex1+" "+vertex2);
									System.out.println("Before wt "+vertex1+" "+weightOfVertex1+" "+vertex2+" "+weightOfVertex2);
									verticesList.
									put(CompareVertex(vertex1, vertex2), weight);
									System.out.println("After wt "+vertex1+" "+verticesList.get(vertex1)+"  "+vertex2+" "+verticesList.get(vertex2));
									
								}
								tempClusterSet.get(v1Index).addweight(maximumWeight(tempClusterSet.get(v1Index).getSet()));
								System.out.println("Updated Cluster weight = "+tempClusterSet.get(v1Index).getWeight());
								tempClusterSet.remove(v2Index);
							}
							else 
							{
							//	break;
							}
						}
						else if (v1Flag==true && v2Flag==false)
						{
							tempClusterSet.get(v1Index).getSet().add(vertex2);
						
							if (weight>weightOfVertex1 || weight>weightOfVertex2)
							{
								System.out.println(" Vertex in IF(true)>ELSE>IF(v1F)>ELSE_IF "+vertex1+" "+vertex2+" " +weight);
							//	System.out.println("wT of small vertex="+verticesList.get(CompareVertex(vertex1, vertex2)));
								verticesList.
								put(CompareVertex(vertex1, vertex2), weight);	
							
							}
						//	System.out.println("Update wT of small vertex="+verticesList.get(CompareVertex(vertex1, vertex2)));
							tempClusterSet.get(v1Index).addweight(maximumWeight(tempClusterSet.get(v1Index).getSet()));
						//	System.out.println(" Updated weight of Cluster= "+maximumWeight(tempClusterSet.get(v1Index).getSet()));
						}
						else if (v2Flag==true && v1Flag==false)
						{
							tempClusterSet.get(v2Index).getSet().add(vertex1);
							if (weight>weightOfVertex1 || weight>weightOfVertex2)
							{
								System.out.println(" Vertex in IF(true)>ELSE>IF(v2F)>ELSE_IF "+vertex1+" "+vertex2 +" " +weight);
								verticesList.
								put(CompareVertex(vertex1, vertex2), weight);	
							}
							tempClusterSet.get(v2Index).addweight(maximumWeight(tempClusterSet.get(v2Index).getSet()));
							System.out.println(" Updated weight of Cluster= "+tempClusterSet.get(v2Index).getWeight());
						}
						else
						{
							for (VertexClusterWeight vertexClusterWeight : tempClusterSet) 
							{
								if (vertexClusterWeight.getSet().isEmpty()) 
								{
									vertexClusterWeight.getSet().add(vertex1);
									vertexClusterWeight.getSet().add(vertex2);
									
									if (weight>weightOfVertex1 || weight>weightOfVertex2)
									{
										System.out.println(" Vertex in IF(true)>ELSE>IF(v1F&v2F=False)>ELSE "+vertex1+" "+vertex2+" "+weight);
										verticesList.put(CompareVertex(vertex1, vertex2), weight);	
									}
									vertexClusterWeight.addweight(maximumWeight(vertexClusterWeight.getSet()));
									System.out.println(" Updated weight of Cluster= "+vertexClusterWeight.getWeight());
									break;
								}
								
							}
						}
						
				}
				
			}
			
			else // (Ratio greater Tolerance -> Create new cluster for new vertex
							//which is not in given list of cluster)
			{
				System.out.println(" Vertex in ELSE(r not) "+vertex1+" "+vertex2+"\n");
				if (firstEdge) 
				{
				
					tempClusterSet.get(0).addVertex(vertex1);
					tempClusterSet.get(1).addVertex(vertex2);

				tempClusterSet.get(0).addweight(weightOfVertex1);
				tempClusterSet.get(1).addweight(weightOfVertex2);
				
				
				System.out.println(" Vertex in firstEdge (r>T) "+tempClusterSet.get(0).getSet()+" "+tempClusterSet.get(0).getWeight());
					firstEdge=false;
					
				}
				
				else
				{	
				boolean v1Flag=false,v2Flag=false;
				int emptyIndex=-1;
				for (VertexClusterWeight vertexClusterWeight : tempClusterSet) 
				{
					List<String>list1=vertexClusterWeight.getSet();
					
					if (list1.contains(vertex1))
						v1Flag=true;
					
					if (list1.contains(vertex2))
						v2Flag=true;

					if (list1.isEmpty() && emptyIndex==-1)
					 {
						emptyIndex=tempClusterSet.indexOf(vertexClusterWeight);
					 }
				}
				
				if (v1Flag==true && v2Flag==true)
				{
					System.out.println(" Vertex in ELSE(r not)>ELSE>IF(v1F&v2F) ");
					// Ignore this Edge as both vertices are in same Index
					
				}
				else if (v1Flag==true && v2Flag==false) 
				{
					System.out.println(" Vertex in ELSE(r not)>ELSE>IF(v1F) ");
					tempClusterSet.get(emptyIndex).addVertex(vertex2);

				//	tempClusterSet.get(emptyIndex).addweight(maximumWeight(tempClusterSet.get(emptyIndex).getSet()));
					tempClusterSet.get(emptyIndex).addweight(verticesList.get(vertex2));
					
				}
				else if (v1Flag==false && v2Flag==true) 
				{
					System.out.println(" Vertex in ELSE(r not)>ELSE>IF(v2F) ");
					tempClusterSet.get(emptyIndex).addVertex(vertex1);
					
				//	tempClusterSet.get(emptyIndex).addweight(maximumWeight(tempClusterSet.get(emptyIndex).getSet()));
				tempClusterSet.get(emptyIndex).addweight(verticesList.get(vertex1));
				}
				else
				{
					System.out.println(" Vertex in ELSE(r not)>ELSE>IF(v1F&v2F=FALSE) ");
					int counter=0;
					int emptyIndex1=-1,emptyIndex2=-1; 
					for (VertexClusterWeight vertexClusterWeight : tempClusterSet) 
					{
						List<String>list1=vertexClusterWeight.getSet();
						
						if (counter!=2) 
						{
							if (list1.isEmpty() )
							{
								if(counter==0)
								emptyIndex1=tempClusterSet.indexOf(vertexClusterWeight);
							
								if(counter==1)
								emptyIndex2=tempClusterSet.indexOf(vertexClusterWeight);

							counter++;
							}
						}
					}
					tempClusterSet.get(emptyIndex1).addVertex(vertex1);
					tempClusterSet.get(emptyIndex2).addVertex(vertex2);

					tempClusterSet.get(emptyIndex1).
					addweight(verticesList.get(vertex1));

					tempClusterSet.get(emptyIndex2).
					addweight(verticesList.get(vertex2));
					

				}
			}
			}

			System.out.println("\n\n");
		}
		
		for (VertexClusterWeight set : tempClusterSet)
		{
			Set<String> tmpSet=new HashSet<String>();
			if (set.getSet().size()!=0)
			{
				tmpSet.addAll(set.getSet());
				clusterSets.add(tmpSet);
			}	
			
		}

		System.out.println("------------------------------");
		for(int g=0;g<tempClusterSet.size();g++)
		{
			System.out.println(tempClusterSet.get(g).getSet()+" @ "+g);
		}
		System.out.println("------------------------------");
		
		return clusterSets;
	}
	
	 //End of VertexCluster

	/********************************************* minimumWeight Method *********************************************/

	private int minimumWeight(List<VertexClusterWeight> tempClusterSet,String obj1, String obj2)
	{
		int v1Index=-1,
			v2Index=-1;

		int wt1=0,
			wt2=0;

		for (int j = 0; j < tempClusterSet.size(); j++)
					{	
						
				
							List<String>list1=tempClusterSet.get(j).getSet();
							System.err.println(list1);
							if (list1.contains(obj1))
							{
								v1Index=j;
							}
							if (list1.contains(obj2))
							{	
								v2Index=j;
							}
					}

					if(v1Index!=-1 && v2Index!=-1)
					{
						System.out.println("MV v1 & v2 set ");
						wt1=tempClusterSet.get(v1Index).getWeight();
						wt2=tempClusterSet.get(v2Index).getWeight();
					}
					else if(v1Index==-1 && v2Index!=-1)
					{
						System.out.println("MV v2=set");
						wt1=verticesList.get(obj1);
						wt2=tempClusterSet.get(v2Index).getWeight();
					}
					else if(v1Index!=-1 && v2Index==-1)
					{
						System.out.println("MV v1=set");
						wt1=tempClusterSet.get(v1Index).getWeight();
						wt2=verticesList.get(obj2);
					}
					else
					{
						System.out.println("MV v1 & v2=Not set");
						wt1=verticesList.get(obj1);
						wt2=verticesList.get(obj2);
					}
		System.out.println("minimumWeight vertices= " +obj1+" "+wt1+"  "+obj2+"  "+wt2);
		return (wt1<=wt2)? wt1 :wt2;
	}

	/********************************************* CompareVertex Method *********************************************/
	
	private String CompareVertex(String vertex1,String vertex2) 
	{
		String resultString=(vertex1.charAt(0) < vertex2.charAt(0))?vertex1:vertex2;
		System.err.println("CompareVertex result="+resultString+"\t"+" vertices= "+vertex1+"  "+vertex2);
		return  resultString;
	}
	

	/********************************************* maximumWeight Method *********************************************/

	private int maximumWeight(List<String> set)
	{
		
		int maxValue=0;
		
		List<Integer> wtList=new ArrayList<Integer>();

		// for (int i = 0; i <set.size() ; i++)
		// {
		// 	for (int j = i+1; j < set.size(); j++)
		// 	{
		// 		int wt1=verticesList.get(set.get(i));
		// 		int wt2=verticesList.get(set.get(j));
				
		// 		System.out.println(">> X="+set.get(i)+" "+wt1+" Y="+set.get(j)+" "+wt2);
		// 		if (wt1<wt2)
		// 		{
		// 			maxValue=wt2;
		// 		}
		// 		else {
		// 			maxValue=wt1;
		// 		}
		// 	}
		// }
		
		for (int i = 0; i <set.size() ; i++)
		{
			int wt1=verticesList.get(set.get(i));

			if (maxValue<wt1)
			{
				maxValue=wt1;	
			}
		}

		// for (int i = 0; i < set.size(); i++)
		//  {
		// 	wtList.add(verticesList.get(set.get(i)));
		// }
		// Collections.sort(wtList);
		// maxValue=(wtList.size()-1);
		return maxValue ;
	}
	
	// Sort the EdgeList based on the weight ( referred from assignment 1 )
	/********************************************* sortHashMapbyWeight Method *********************************************/

	public  HashMap<String,myEdge> sortHashMapbyWeight( HashMap<String,myEdge> myList) 
	{
		List<Map.Entry<String, myEdge>> tmpList=
				new LinkedList<Map.Entry<String,myEdge>>(myList.entrySet());
		

		Collections.sort(
				tmpList,
				new Comparator<Map.Entry<String, myEdge>>() {
					@Override
					public int compare(Entry<String, myEdge> o1, Entry<String, myEdge> o2)
					{
							int value1=o1.getValue().getWeight();
							int value2=o2.getValue().getWeight();
							String vertex1=o1.getValue().getSource();
							String vertex2=o2.getValue().getSource();
							
							if (value1!=value2)
							{
								return value1-value2;	
							}
							return vertex1.compareTo(vertex2);
					}
				});	
		
				
		HashMap<String, myEdge> resultList=
				new LinkedHashMap<String,myEdge>();
		
				 for (Entry<String, myEdge> me : tmpList) { 
			            resultList.put(me.getKey(), me.getValue()); 
			        } 
				 
		return resultList;
	}
	
	/********************************************* PrintGraph Method *********************************************/

	public void PrintGraph()
	{
		// Printing all elemnts of a VertexHashMap 
		System.out.println("Total entry to vertexHashMap = "+vertexListHashMap.size());
	
		
		
	
		//Printing all elements of Edgelist after sorting
		
		System.err.println("\n\nEdge list after sorting\n");
		HashMap<String, myEdge> sortedEdgeList=sortHashMapbyWeight(edgeList);
		
		for (Map.Entry<String, myEdge> set : 
			sortedEdgeList.entrySet()) 
		{ 
			System.out.println(set.getKey() + " "+ set.getValue().getWeight());
		}
		
	}
	
	/********************************************* printVertices Method *********************************************/

	private void printVertices()
	{
		System.err.println("Vertex List");
		
		for (Map.Entry<String, Integer> object : verticesList.entrySet()) 
			{
				System.out.println(object.getKey() +"  "+object.getValue());
			}
	}
	
	
	private void printverticewithWeight()
	{
		System.out.println("\n_______VerticeList_______________-\\n");
			for (Map.Entry<String,Integer> list : verticesList.entrySet()) {
				System.out.println("verticesList "+list.getKey()+"  "+list.getValue());
			}
			System.out.println("______________________________________");
			
			
	}

	/********************************************* MAIN Method *********************************************/
	public static void main(String[] args)
	{
		
		//float x =(float)10/3;
	//	System.out.println("X= "+x);
		MyTestGraph graph=new MyTestGraph();
		
		graph.addEdge(" A", "B", 3);
		 graph.addEdge("A", "H", 1);
		graph.addEdge("I", "H", 1);
		graph.addEdge("I", "B", 4);
		graph.addEdge("B", "C", 7);
		graph.addEdge("I", "C", 8);
		graph.addEdge("G", "H", 7);
		graph.addEdge("F", "G", 7);
		graph.addEdge("H", "J", 10);
		graph.addEdge("D", "I", 12);
		graph.addEdge("D", "C", 14);
		graph.addEdge("D", "E", 8);
		graph.addEdge("J", "F", 3);
		graph.addEdge("E", "F", 2);
		graph.addEdge("J", "D", 1);

		graph.PrintGraph();	
	//	graph.printVertices();
		System.out.println(graph.clusterVertices(2));
		graph.printverticewithWeight();

		
	}

}
