import java.util.ArrayList;
import java.util.List;


public class VertexClusterWeight
{
	private List<String> vertexSet=new ArrayList<String>();;
	private int weight;
	
	
	public void addVertex(String str) {	
			this.vertexSet.add(str);
	}
	public void addweight(int wt)
	{
		this.weight=wt;
	}
	
	public  List<String> getSet() 
	{
		return this.vertexSet;
	}
	public int getWeight()
	{
		return this.weight;
	}
	
	
}
