package BinarySearchTree;

public class asw {

	public static void main(String[] args) {
	
		int nBlanks=32;
		for(int j=0; j<nBlanks*2-2; j++) {
            System.out.print("--");
        }

	}

}
