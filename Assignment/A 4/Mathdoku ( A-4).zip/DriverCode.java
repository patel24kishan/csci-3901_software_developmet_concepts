import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class DriverCode {
    public static void main(String[] arg)
    {
        Mathdoku mathdoku=new Mathdoku();
        try {
            mathdoku.loadPuzzle(new BufferedReader(new FileReader("test2.txt")));
        } catch (FileNotFoundException e) {
                System.out.println("File not Found!!!");
        }
        mathdoku.validate();
       mathdoku.solve();
       
      System.out.println( mathdoku.print());
      System.out.println( mathdoku.choices());
 
    }
}
