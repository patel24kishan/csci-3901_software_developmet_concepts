import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Mathdoku
 {
 
    public List<String> bufferList=new ArrayList<String>(); // temporary stores string fromm bufferStream
    public Map<String,myOperations> operationsList=new HashMap<String,myOperations>(); //store operation
    public Map<String,List<List<Integer>>> possibleValuesSetByGroup=new HashMap<String,List<List<Integer>>>(); //store operation
    public Set<String> groupName=new HashSet<String>(); //Stores unqiue group type
    public int puzzleSizeValue=0;
    public boolean ReadPuzzleFileFlag=false,ValidateFlag=false,SolveFlag=false;
 
    public int[][] TempSolutionMatrix;
    public String[][] grpMatrix; //used only for storing group values and checking validity of the file
    public int traversalChoices=0; //Number of choices before solution was found or not found
    // Initialize Constructor
    public Mathdoku() {
 
    }
/**************************************** ReadPuzzleFile method *****************************************/
    
    boolean loadPuzzle( BufferedReader bufferedReader)
     {
        String Line="";

        //Read the bufferedStream until end of the line
             try {
               while ((Line = bufferedReader.readLine()) != null) {
                   if (!Line.isBlank()) {
                       bufferList.add(Line);
                   } 
                   else // Consider blank line as invalid input
                   {
                       return false;
                   }
               }
               bufferedReader.close();
           } catch (IOException e) {
              // e.printStackTrace();
           }
       
           ReadPuzzleFileFlag=true; //Checks ReadPuzzleFileflag if file read successfully
       return true;
    }
 
/**************************************** Validate method *****************************************/
/*   Note that I have allowed white spaces for the section 2 of input file that
    for example, puzzle size=5 and "aab bb" -> it will be treated as valid "aabbb" string

    Also, validate() is not functioned to detecting gap in between cells of similar group as follow
    for exmaple: "abab" -> invalid | "aabb" -> valid
    It will allow both type of strings
 */  

public boolean validate()
   {
       boolean intFlag=true; 
        
       if (ReadPuzzleFileFlag) // Checks if puzzle is read successfully
        {
           if (bufferList.size()==0)
            {
        
             return false;   
           }
       try 
       {    
           if(intFlag) // checks if first line is Integer value
           {
               
                   
               puzzleSizeValue= Integer.parseInt(bufferList.get(0)); 
               
               //checks if integer is a negative or zero value
               if (puzzleSizeValue<=0) 
               {
                   return false;
               }
               //Initialize temporary matrix for back tracking
               TempSolutionMatrix=new int[puzzleSizeValue][puzzleSizeValue]; 
               grpMatrix=new String[puzzleSizeValue][puzzleSizeValue];
                intFlag=false;
            }
            else
            {
                return false;
            }
       }  
       catch (NumberFormatException e) 
       {

       } 
 
       // Checks section 2 of file which is the matrix and assigns each value to its corresponding cell in the Matrix
       for (int i = 1; i <= puzzleSizeValue; i++)
        { 
           String TmpString=bufferList.get(i).replaceAll("\\s+",""); //Remove white spaces between characters
          
           if (TmpString.length()==puzzleSizeValue) // Checks if length of string is equals to puzzle size
           {
           for (int j = 0; j < TmpString.length(); j++)
           {  
               String C=Character.toString(TmpString.charAt(j));
               groupName.add(C);
               grpMatrix[i-1][j] =C;    
           } 
           }
        else
        {
            return false;
        }
       }
 
        // Checks if Section 3 of input i.e Operations are valid as follow:
        // First character is group value 
        // Secong is the output value of that group
        // Third is the operation i.e *,+,-,/,=

        for (int i = puzzleSizeValue+1; i <bufferList.size(); i++)
        {
            String[] tmpString=bufferList.get(i).split("\\s+");// splits the operations string at " "
            String operationKey="";
            myOperations myObject=new myOperations();
 
                if (tmpString[0].length()==1) {
                    if (1<tmpString.length && tmpString[1].matches("-?\\d+")) {
                        
                        operationKey=tmpString[0];
                        myObject.setValue(Integer.parseInt(tmpString[1]));
                        if (2<tmpString.length) {
                            myObject.setOperations(tmpString[2]);
                        }
                        else
                        {
                            
                            return false;
                        }
                    }
                    else{
                      
                        return false;
                    }
                 }
                 else{
                   
                     return false;
                 }
                 
            operationsList.put(operationKey, myObject); //add this variables to operationsList with group value as
        }                                               // the key and operation & output value as the value
       
        //check if number of operations matches the number of group
        if (groupName.size()!=operationsList.size())
         {
          
            return false;
        }
    }
    else //returns false if file not read successfully
    {
        return false;
    }

    // create list of index postion of each cell in a group  and store in respective operationList
    for (Map.Entry<String,myOperations> obj1: operationsList.entrySet())
    {
        List<CellLocation> locations=new ArrayList<CellLocation>();
        String category=obj1.getKey();
        for (int i = 0; i < grpMatrix.length; i++)
        {
           for (int j = 0; j < grpMatrix.length; j++)
           {
               String matrixCategory=grpMatrix[i][j];
               if(matrixCategory.equals(category))
               {
                CellLocation loc=new CellLocation(i, j);
                locations.add(loc);
               }
            }
           
        }
        obj1.getValue().setLocation(locations);
    }
    
       ValidateFlag=true;   //Checkvalidateflag for successfull validation   
       return checkNumberOfCells(grpMatrix); //Validate returns true only if checkNumberCells returns true
   }
 
   /**************************************** CheckNumberOfCells method *****************************************/

   //Check if number of cells are valid according to the type of operations
   private boolean checkNumberOfCells (String[][] list)
   {
    List<String> CellList=new ArrayList<String>();
      for (int i = 0; i < list.length; i++)
      {
          for (int j = 0; j < list.length; j++) {
           CellList.add(list[i][j]);
      }
    }
      // hashmap to store the frequency of element 
      Map<String, Integer> CellCount = new HashMap<String, Integer>(); 
  
      //Calculating occurences of each cell
      for (String i : CellList) { 
          Integer j = CellCount.get(i); 
          CellCount.put(i, (j == null) ? 1 : j + 1); 
      } 
 
      //Checks if number of cells for each operation satisfies their condition
      // "=" -> exactly 1 cell 
      //"-" & "/" -> exactly 2 cells
      //"*" & "+-> at least 2 cells
      for (Map.Entry<String,myOperations> obj: operationsList.entrySet()) {
           String cellKey=obj.getKey();
           String operator=obj.getValue().getOperation();
           int cellCount=CellCount.get(cellKey);
 
           if( operator.equals("=") && cellCount==1)
           {
           }
           else if(((operator.equals("-") || operator.equals("/")) && cellCount==2))
           {
           }
           else if(((operator.equals("+") || operator.equals("*")) && cellCount>=2))
           {
           }
           else
            {
                return false;
            }           
        
     }
       return true;
   }
   
    /**************************************** Solve method *****************************************/
  
    // This method checks if a solution is available based on the given input file
    public boolean solve()
    {
        if (ReadPuzzleFileFlag && ValidateFlag) //solve only if validate() and loadPuzzle() executed successfully 
        {       
        Map<String,myOperations>  TempOperationList=new HashMap<String,myOperations>();
        TempOperationList.putAll(operationsList); //Copy of operationList for better manipulation
        Set<String> removeSet=new HashSet<String>();

        // Sets value in TempMatrix For each cell of "=" operation
        for (Map.Entry<String,myOperations> listObj : TempOperationList.entrySet())
        {
            if(listObj.getValue().getOperation().equals("="))
            {
                int x=listObj.getValue().getLocation().get(0).getX();
                int y=listObj.getValue().getLocation().get(0).getY();
                int value=listObj.getValue().getValue();
                if (isOk(x, y, value))
                {
                TempSolutionMatrix[x][y]=value; //Set value in temporary solution list
                removeSet.add(listObj.getKey());
                }
                else
                    return false;  
            }   
        }
            TempOperationList.keySet().removeAll(removeSet); //removes "=" operation group pair from TempOperationList
        
        //Generate Possible value set for each operation and stores in possibleValuesSetByGroup
            for (Map.Entry<String,myOperations> listObj : TempOperationList.entrySet())
        {
            String operator=listObj.getValue().getOperation();
            int output=listObj.getValue().getValue();
            int locationsSize=listObj.getValue().getLocation().size();
            List<List<Integer>> ABCList=new ArrayList<List<Integer>>(createPossibleSets(operator,output,locationsSize));
            possibleValuesSetByGroup.put(listObj.getKey(),ABCList);   
         }
 
         //Create set of each group value
        String[] groupSet= possibleValuesSetByGroup.keySet().toArray( new String[possibleValuesSetByGroup.keySet().size()]);

        generateMatrix(TempOperationList,groupSet,0); //Call generateMatrix
    }  
    else // Return false if ReadPuzzle() & validate() not executed successfully
    {
          return false;  
    }

         if(SolveFlag)
          return true;
         else
          return false;
        
    }
 
     /**************************************** print() method *****************************************/
  
     //Prints the current state of the TempSolutionMatrix
    String print()
    {
        String finalString="";
        if (ReadPuzzleFileFlag && ValidateFlag &&SolveFlag) {
        
        for (int i = 0; i < TempSolutionMatrix.length; i++)
        {
        for (int j = 0; j < TempSolutionMatrix.length; j++)
        {
            System.out.print(TempSolutionMatrix[i][j]);   
        }
           System.out.println();
       }
    }  
    return finalString;
    }
        /**************************************** choices() method *****************************************/
        //Prints every count of traversal choices made
        int choices()
    {
        return traversalChoices;   
    }
    
        /**************************************** generateMatrix method *****************************************/

    private void generateMatrix(Map<String,myOperations> TempList,String[] groupSet,int groupSetIdx){
        
        if (groupSetIdx==groupSet.length) //Checks if groupIdx exceeds groupSet size
         {
            return;
        }
        String group=groupSet[groupSetIdx]; //Get group value from groupSet
        List<List<Integer>> possibleValueList = new ArrayList<List<Integer>>(possibleValuesSetByGroup.get(group)); //PossibleValueSet of defined group
        List<CellLocation> groupLocationList= new ArrayList<CellLocation>(operationsList.get(group).getLocation());// list of CellLocation of defined group
        
                    for (int i = 0; i<possibleValueList.size();i++) {
                        boolean ValidPossibleSet =true; // Flag to check if a value set of a group is valid and can be used in possible solution
                        List<CellLocation> TempLocList= new ArrayList<CellLocation>();
                        for (int j = 0; j<groupLocationList.size(); j++){
                            int row=groupLocationList.get(j).getX();
                            int col=groupLocationList.get(j).getY();
                            int value=possibleValueList.get(i).get(j);
                            if (isOk(row, col, value))
                            {
                                TempSolutionMatrix[row][col]=value;  // Assign value from the possibleValue set
                                TempLocList.add(groupLocationList.get(j));
                                traversalChoices++; //Increment when value is assigned
                            }
                            else
                            {
                                ValidPossibleSet=false;
                                resetPosition(TempLocList); //reset each value in the matrix if the given set can't be used in the solution  
                                break;
                            }
                        }

                        if(ValidPossibleSet)
                        {
                            generateMatrix(TempList, groupSet, groupSetIdx+1);
                            if (NonZeroPuzzle()) //return true if possible solution found
                              { 
                                  SolveFlag=true;
                                   break;
                                }
                            else {
                                resetPosition(TempLocList); //reset each current assigned position in TempSolutionMatrix to zero 
                                continue;
                            }
                        }

                        //check if last set of the possibleValueList can't be used in solution then return empty
                        if (ValidPossibleSet==false&& i==possibleValueList.size()-1)
                        {
                            return;
                        }   
                    }
    }

 /**************************************** NonZeroPuzzle method *****************************************/
 
    // Checks if any index position on TempSolutionMatrix is zero
    private boolean NonZeroPuzzle() 
    {
        for (int i = 0; i < puzzleSizeValue; i++) {
            for (int j=0; j<puzzleSizeValue; j++) {
                if (TempSolutionMatrix[i][j]==0)
                   { return false;}
            }
        }   
        return true;
    }

    /**************************************** resetPosition method *****************************************/
 
    // Reset each location value in the list to zero
    private void resetPosition(List<CellLocation> list) 
    {
        if (list.size()!=0)
         {
            for (int i = 0; i < list.size(); i++) {
            
                int row=list.get(i).getX();
               int col=list.get(i).getY();
               TempSolutionMatrix[row][col]=0;
            }
         }
    }
 
     /**************************************** isOk isInRow isInCol method *****************************************/
 
    // Checks if a predicted value is in the given row and column
     public boolean isOk(int row, int col, int number) {
        return (!isInRow(row, number)  &&  !isInCol(col, number));
    }
 
    public boolean isInRow(int row, int number) {
        for (int i = 0; i < puzzleSizeValue; i++)
            if (TempSolutionMatrix[row][i] == number)
                return true;
        return false;
    }
 
    public boolean isInCol(int col, int number) {
        for (int i = 0; i < puzzleSizeValue; i++)
            if (TempSolutionMatrix[i][col] == number)
                return true;
        return false;
    }
 
    /**************************************** createPossibleSets method *****************************************/
 
    // Creates every possible set of values for each group based on it's operations
     private List<List<Integer>> createPossibleSets(String operator,int value,int size )
     {
         int[] possibleValues=new int[puzzleSizeValue];
         // Create list of possilbe value based on the puzzle size 
         for(int i = 0; i < puzzleSizeValue; i++)
         {
            possibleValues[i]=i+1;
         }
        List<List<Integer>> list = new ArrayList<List<Integer>>();
        switch(operator)
        {
            //For "+"
            case "+":
            List<Integer> tmp_list1 = new ArrayList<Integer>();
            list=subSequenceSum(list,puzzleSizeValue,tmp_list1,value,size);
            break;
 
            //For "-"
            case "-":
            for (int i = 1; i <= puzzleSizeValue; i++)
            {
                //List<Integer> tmp_list = new ArrayList<Integer>();
                for (int j = i; j <= puzzleSizeValue; j++)
                {
                    if ((i-j)==value || (j-i)==value)
                    {
                        list.add(new ArrayList<Integer>(Arrays.asList(i,j)));    
                        list.add(new ArrayList<Integer>(Arrays.asList(j,i)));   
                    }    
                }  
            }  
            break;
                
            //For "*"
            case "*":
                    List<Integer> tmp_List= new ArrayList<Integer>();
                    List<List<Integer>> ResultList=new ArrayList<List<Integer>>();
                        list= subSequenceMultiply(5, value,size,  tmp_List,ResultList);
            break;
 
            //For "/"
            case "/":
                for(Integer i=1; i<=puzzleSizeValue; i++){
                // List<Integer> tmp_list = new ArrayList<Integer>();
                for(Integer j=1; j<=puzzleSizeValue; j++){
                    if(Math.abs(i/j) == value && (i%j) == 0){
                        list.add(new ArrayList<Integer>(Arrays.asList(i,j)));    
                    list.add(new ArrayList<Integer>(Arrays.asList(j,i)));
                    }
                }
            }
             break;
        }
        return list;
     }
 
       /**************************************** subSequenceMultiply method *****************************************/
        //This solution is rougly based on a solution of similar problems from GeekForGeeks 
       //Creates every possible set of values for "*" operation
     private static List<List<Integer>> subSequenceMultiply(int puzzleSizeValue, int output, int pairSize,
     List<Integer> tmp_List,List<List<Integer>> ResultList) //temporary list to store each value of a set
     {
 
        List<Integer> list = new ArrayList<Integer>();
        for (int i = 1; i <= puzzleSizeValue; i++)
        {
            list.add(i);
        }
        //checks number of values in the temporary list is same as the number of cells for the operation
        if (tmp_List.size() == pairSize) {
            int product = 1;
            
            for (int value: tmp_List) {
                product *= value;
            }
        // checks if product of each value on the temporary list is same as the output of this group
        //if it is then add it to the PossibleValueSet of that group
        if (product == output) {
                ResultList.add(new ArrayList<Integer>(tmp_List));   
             }  
            return ResultList;
        }
 
        for (Integer i: list) {
            
            // add a number to the solution
            tmp_List.add(i);
            subSequenceMultiply(puzzleSizeValue, output, pairSize, tmp_List, ResultList); //recursive call
            
            // keep on changing the last element with all the possible combinations to get set of values with different order
            tmp_List.remove(tmp_List.size()-1);
        }
        return ResultList;
    }
 
  /**************************************** subSequenceSum method *****************************************/
        //This solution is rougly based on a solution of similar problem from GeekForGeeks 
       //Creates every possible set of values for "*" operation
   
       private List<List<Integer>> subSequenceSum(List<List<Integer>> ans,int puzzleSizeValue,  List<Integer> temp,int output,int pairSize)
    {
        int a[] = new int[puzzleSizeValue];
        for (int i = 0; i < a.length; i++)
        {
            a[i] =i+1;
        }
 
       //checks number of values in the temporary list is same as the number of cells for the operation
        if (temp.size()==pairSize)
        {    
            int sum=0;
            for (int value: temp) {
                sum += value;
            }
        
            // checks if sum of each value on the temporary list is same as the output of this group
            //if it is then add it to the PossibleValueSet of that group
            if (sum == output) {
                ans.add(new ArrayList<Integer>(temp));
        }
    }
        else {
            for (int i = 0;i < a.length; i++) {

                temp.add(a[i]);
                subSequenceSum(ans, puzzleSizeValue,temp,output,pairSize); 
                // keep on changing the last element with all the possible combinations to get set of values with different order
          
                temp.remove(temp.size() - 1);
            }
        }
        return ans;
    }
}
 

