/*
    This class stored index value i.e x position and y position of each cell 
    in single object
 */
public class CellLocation {
    private int cX;
    private int cY;

    public CellLocation(int x,int y)
    {
        this.cX=x;
        this.cY=y;
    }

    public int getX()
    {
        return this.cX;
    }

    public int getY()
    {
        return this.cY;
    }
}
