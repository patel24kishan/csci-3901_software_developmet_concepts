
// stores the cell values
public class Cell {

	int value;
	char group;
	
	public Cell(int value, char group) {
		this.value = value;
		this.group = group;
	}
	
}
