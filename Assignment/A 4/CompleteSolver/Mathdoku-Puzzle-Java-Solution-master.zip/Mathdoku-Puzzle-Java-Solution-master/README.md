# Mathdoku-Kenken-Calcudoku-puzzle-solver using Java

To see what the problem is, visit http://www.mathdoku.com/
The problem description can be found in the "Mathdoku Problem Statement.pdf" file.

Use the test1 and test2 files as samples to see how the program runs.
Go to the MainClass.java file and update the variable "inputfilepath" with the local path where you have kept test1.txt or test2.txt
