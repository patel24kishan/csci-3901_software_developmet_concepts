//MAin Method for MySQL.class
public class DriverCode {
    
    public static void main(String[] args)
     {
         MySQL object = new MySQL();
         object.XmlGeneration();
     }
}